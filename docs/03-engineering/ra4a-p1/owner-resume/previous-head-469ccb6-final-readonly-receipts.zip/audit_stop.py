"""Read-only final source/local evidence and actual hosted startup RED audit."""
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
DOCS = HERE.parents[1]
HEAD = '469ccb6cf88b7a66d97b2572be7653048a513dd0'
BASE = '225ded57add21680171cfaecac9f89df6b1af155'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def tree(ref):
    return {s.split('\t')[1]: s.split('\t')[0]
            for s in git('ls-tree', '-r', ref).decode().splitlines()}


assert git('rev-parse', 'HEAD').decode().strip() == HEAD
before, after = tree(BASE), tree(HEAD)
assert len(before) == 3176
assert all(after.get(p) == v for p, v in before.items())
allowed = ('db/migrations/', 'vrae/persistence/', 'integration/ra4a/',
           'tests/persistence/', 'infra/ra4a/', 'docs/03-engineering/ra4a-p1/')
assert all(p.startswith(allowed) or p in {'requirements-ra4a.lock', '.github/workflows/ra4a-pg.yml'}
           for p in after.keys() - before.keys())
assert not git('diff', '--name-only', '2fae64777b44898281b9044169c4cc73ff63c19c', HEAD,
               '--', 'vrae', 'tests', 'db', 'integration', 'infra', '.github', 'requirements-ra4a.lock').strip()
assert not git('diff', '--name-only', 'HEAD').strip()
scope = read(DOCS / 'SOURCE_SCOPE.json')
for row in scope['frozen_sources']:
    assert after[row['path']] == row['mode_blob']
    assert hashlib.sha256(git('show', HEAD + ':' + row['path'])).hexdigest() == row['git_sha256']
archive_path = DOCS / 'raw-local-evidence.zip'
manifest = read(DOCS / 'RAW_LOCAL_MANIFEST.json')
assert hashlib.sha256(archive_path.read_bytes()).hexdigest() == manifest['sha256']
with zipfile.ZipFile(archive_path) as z:
    assert z.testzip() is None
    for row in manifest['members']:
        assert hashlib.sha256(z.read(row['member'])).hexdigest() == row['sha256']
local = []
for runtime in ('py311', 'py313'):
    folder = DOCS / 'final-source-2fae647' / runtime
    counts = {}
    for filename, expected in [('postgres.xml', 54), ('pure.xml', 11)]:
        suites = ET.parse(folder / filename).getroot().findall('testsuite')
        assert len(suites) == 1
        suite = suites[0]
        assert int(suite.attrib['tests']) == expected
        assert all(int(suite.attrib[k]) == 0 for k in ('failures', 'errors', 'skipped'))
        assert len(suite.findall('testcase')) == expected
        counts[filename] = dict(suite.attrib)
    cat = read(folder / 'pg-catalog-and-calls.json')
    assert len(cat['calls']) == 54 and all(r['outcome'] == 'passed' for r in cat['calls'])
    commands = read(folder / 'commands.json')
    assert all(r['exit'] == 0 for r in commands['commands'])
    local.append({'runtime': runtime, 'python': commands['python'], 'junit': counts})
assert all(read(DOCS / 'final-teardown' / 'teardown.json')[k] is True for k in
           ('owned_container_removed', 'owned_network_removed', 'owned_volume_removed'))
assert not (ROOT / 'infra/ra4a/.venv/lab-state.json').exists()
pg = read(HERE / 'pg-run.json')
jobs = read(HERE / 'pg-jobs.json')['jobs']
assert pg['head_sha'] == HEAD and pg['status'] == 'completed' and pg['conclusion'] == 'failure'
assert len(jobs) == 2 and read(HERE / 'pg-artifact-metadata.json')['artifacts'] == []
pg_proof = []
for job in jobs:
    raw = (HERE / ('job-' + str(job['id']) + '.log')).read_bytes()
    log = raw.decode('utf-8-sig')
    assert job['status'] == 'completed' and job['conclusion'] == 'failure'
    assert all(s in log for s in (HEAD, BASE, read(HERE / 'merge.json')['sha']))
    assert 'show server_version_num' in log and 'non-zero exit status 2' in log
    assert 'RA4A_P1_REAL_PG_RECEIPT=' not in log
    failed = [s['name'] for s in job['steps'] if s['conclusion'] == 'failure']
    assert failed == ['Start owned synthetic PG16 lab on host loopback']
    assert any(s['conclusion'] == 'skipped' for s in job['steps'])
    pg_proof.append({'job': job['name'], 'id': job['id'], 'url': job['html_url'],
                     'conclusion': 'failure', 'business_calls_executed': 0,
                     'junit': 'NOT_GENERATED', 'hosted_teardown_absence': 'UNPROVEN',
                     'decoded_log_sha256': hashlib.sha256(raw).hexdigest(),
                     'root_cause': 'UNCONFIRMED; psql stderr not persisted'})
result = {'status': 'P1_BLOCKED_CRITICAL_STOP_PG_CANNOT_RUN', 'head': HEAD, 'main': BASE,
          'merge': read(HERE / 'merge.json')['sha'],
          'ordered_parents': [r['sha'] for r in read(HERE / 'merge.json')['parents']],
          'preserved_original_blob_modes': len(before), 'new_source_set_sha256': scope['source_set_sha256'],
          'local_archive_sha256': manifest['sha256'], 'local_actual': local,
          'local_teardown_absence_verified': True, 'hosted_pg_actual': pg_proof,
          'native_approval_or_sharegrant': 0, 'production_authority': False,
          'implementation_changes_stopped': True, 'draft': True, 'merged': False}
out = HERE / 'CRITICAL_STOP_RECEIPT.json'
assert not out.exists()
out.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, indent=2))
