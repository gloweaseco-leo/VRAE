"""Archive raw B6 evidence without dropping failed attempts."""
import hashlib
import json
from pathlib import Path
import re
import zipfile

root = Path(__file__).resolve().parents[4]
evidence = root / 'docs/03-engineering/ra1b-evidence'
summary = {'special_runs': [], 'source_sha256': {}}
for number in range(2, 22):
    folder = evidence / f'b6-special-{number:02d}'
    events = json.loads((folder / 'lifecycle.json').read_text())
    commands = json.loads((folder / 'summary.json').read_text())
    exits = {c['name']: c['exit_code'] for c in commands}
    assert exits['worker_kill-worker'] == 137
    for name in ('kernel-control', 'kernel-deny', 'sandbox', 'worker_kill-automatic-exit',
                 'worker_kill-remove', 'worker_kill-volume-remove'):
        assert exits[name] == 0, (folder, name)
    for name in ('worker_kill-process-absence', 'worker_kill-cleanup-proof',
                 'worker_kill-volume-cleanup-proof'):
        assert exits[name] == 1, (folder, name)
    assert 'PRE_KILL_COUNTERS {"bait": 0, "writes": 0}' in (folder / 'worker_kill-worker.log').read_text()
    agent = [json.loads(line) for line in (folder / 'worker_kill-browser-log.log').read_text().splitlines()
             if line.startswith('{"event":')]
    timeline = {v['event']: v['monotonic_ns'] for v in agent}
    names = ['control_socket_eof', 'relay_channel_closed', 'chromium_kill_sent',
             'control_socket_close_requested', 'chromium_reaped', 'pid1_exit']
    assert all(n in timeline for n in names), folder
    assert [timeline[n] for n in names] == sorted(timeline[n] for n in names)
    observed = next(v for v in events if v['event'] == 'automatic_exit_observed')
    assert observed['elapsed_seconds'] < 5
    summary['special_runs'].append({'run': folder.name,
        'wait_seconds': observed['elapsed_seconds'],
        'agent_eof_to_pid1_exit_seconds': (timeline['pid1_exit']-timeline['control_socket_eof'])/1e9,
        'agent_timeline': agent, 'supervisor_timeline': events})
for file in ('scripts/verify_ra1b.py', 'infra/ra1b/agent.py', 'infra/ra1b/seccomp.json',
             'infra/ra1b/Dockerfile', 'infra/ra1b/Worker.Dockerfile'):
    summary['source_sha256'][file] = hashlib.sha256((root/file).read_bytes()).hexdigest()
summary['clock_scope'] = 'Supervisor Windows and Agent Linux VM clocks have separate origins; compare durations within each clock only.'
summary['special_passed'] = len(summary['special_runs'])
summary['special_failed'] = 0
summary['special_skipped'] = 0
summary['failed_environment_attempts'] = ['b6-special-01: Docker config/pipe permissions; no attack ran']
members = {}
with zipfile.ZipFile(evidence/'b6-raw.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(evidence.glob('b6-*/*')):
        if path.is_file():
            content = path.read_bytes()
            name = path.relative_to(evidence).as_posix()
            archive.writestr(name, content)
            members[name] = hashlib.sha256(content).hexdigest()
summary['archive_sha256'] = hashlib.sha256((evidence/'b6-raw.zip').read_bytes()).hexdigest()
summary['archive_members_sha256'] = members
(evidence/'b6-summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps({'special_passed': summary['special_passed'],
    'max_wait_seconds': max(r['wait_seconds'] for r in summary['special_runs']),
    'max_agent_seconds': max(r['agent_eof_to_pid1_exit_seconds'] for r in summary['special_runs']),
    'archive_members': len(members), 'archive_sha256': summary['archive_sha256']}))
