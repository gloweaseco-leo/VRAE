RA4A P1 本轮交付回执 — **BLOCKED，未达到 P1 FINAL PASS 条件**。

代码和本地真 PG 证据已提交；按 Issue #62 的 Critical STOP，新增托管 PG 启动失败后已停止实现修改。没有改生产权限、降低断言或重试制造通过。

| 实测范围 | 实际结果 |
| --- | --- |
| 本地 Python 3.11.15 / PostgreSQL 16.15 | 54 PG PASS + 11 pure PASS；0 fail/error/skip/xfail |
| 本地 Python 3.13.13 / PostgreSQL 16.15 | 54 PG PASS + 11 pure PASS；0 fail/error/skip/xfail |
| [原 CI：Python 3.11](https://github.com/gloweaseco-leo/VRAE/actions/runs/43240818712/job/131260390016) | SUCCESS；2199 PASS / 25 既有 SKIP |
| [原 CI：Python 3.13](https://github.com/gloweaseco-leo/VRAE/actions/runs/43240818712/job/131260390119) | SUCCESS；2199 PASS / 25 既有 SKIP |
| [原 CI：isolated-http](https://github.com/gloweaseco-leo/VRAE/actions/runs/43240818712/job/131260389518) | SUCCESS；2223 PASS / 1 既有 SKIP |
| [原 CI：isolated-browser](https://github.com/gloweaseco-leo/VRAE/actions/runs/43240818712/job/131260389936) | SUCCESS；安全原始 ZIP 已下载并逐项校验 |
| [新增 PG：Python 3.11](https://github.com/gloweaseco-leo/VRAE/actions/runs/43240819476/job/131260391662) | 启动阶段 FAILURE；业务测试 0 执行；JUnit 未生成 |
| [新增 PG：Python 3.13](https://github.com/gloweaseco-leo/VRAE/actions/runs/43240819476/job/131260391478) | 启动阶段 FAILURE；业务测试 0 执行；JUnit 未生成 |

精确对象：
- 最终候选 HEAD：`469ccb6cf88b7a66d97b2572be7653048a513dd0`。
- 最新 main：`225ded57add21680171cfaecac9f89df6b1af155`。
- 实际测试 merge-ref：`249854c375fccecd94f4d959f52c0a74a2e024c7`。
- 已读取 Git merge 对象，ordered parents 为 **[main 225ded57…, HEAD 469ccb6c…]**；四份原 CI 和两份失败 PG checkout 日志均对应此 merge-ref。
- 本地测试源码：`2fae64777b44898281b9044169c4cc73ff63c19c`；到最终 HEAD 所有 SQL/生产新增模块/测试/infra/workflow/依赖 blob 不变。
- 原 main **3176 个 blob/mode 全保留**，仅 Issue #62 授权新路径，工作区无 tracked 修改。
- 新增源码集合 SHA256：`ee2bdc9edf8b197f96c4f792ec760487bb6b357f343e49c8ee8dfff7abc2bdf6`。
- 实际 SQL migration v1 SHA256：`0557738e22e83a6f1c991e8c2a796749ce43845ad80fec44d8dc4c891fd9b5e2`。
- [已提交原始本地证据 ZIP](https://github.com/gloweaseco-leo/VRAE/blob/469ccb6cf88b7a66d97b2572be7653048a513dd0/docs/03-engineering/ra4a-p1/raw-local-evidence.zip)：165698 bytes，SHA256 `78f5b0b440f631c4c44a914132e0f1c20bde94279ef19287db57307fb9e41d2f`；全部成员 CRC/SHA 已复核；双 Python 完整 JUnit 在已提交 `final-source-2fae647/py311|py313` 中。
- [原 CI 安全 artifact](https://github.com/gloweaseco-leo/VRAE/actions/runs/43240818712/artifacts/13954209437)：312744 bytes，SHA256 `68f0813e5412d1b3348ee4751f40c035615ce0858896d5509f66cc9672fc0b92`，与 GitHub artifact digest 完全一致。

已核查原四 CI 的实际证据：三个 full-test job 各 **127/127 D1/D2** 与 **118/118 RA3C V2（64 primary + 54 denial）** actual call reports 全通过；原冻结 source/profile SHA 不变、无 setup/call problems。HTTP 24 条真实 network records 均 bait=0、external_routes=false、uid=65532。安全 ZIP 247 成员、245 命令、540 生命周期事件、16 安全场景；控制组 4 项 socket 创建成功，拒绝组 4 项 EPERM、只读根 errno30；进程/容器/卷清理及自动退出先于 supervisor cleanup 均通过。该安全证据只证明原受控浏览器/HTTP 沙箱，**不外推为新 PG bridge 的 egress 隔离**。

阻断和异常记录：
1. 新 PG 两个 job 的 `pg_isready` 返回 0 后，读取 `show server_version_num` 的 `psql` 返回 2。日志未保存 psql stderr，根因 **UNCONFIRMED**；临时初始化服务器/重启就绪竞争只是推测。不是 54 个业务测试的 FAIL，也不是通过。
2. 新 PG 工作流无 artifact/JUnit，不能声称托管角色/RLS/事务/恢复或 teardown 验收完成。异常分支调用过 own-resource 清理命令，但未持久化其返回码，故 hosted cleanup absence **UNPROVEN**。本地最终 teardown 及当前 own-label 容器/网络/卷不存在已独立复核。
3. 先前本地网络发布 setup RED、teardown optional Tmpfs 字段错误及修订前后实际运行全部保留，见已提交 ACCEPTANCE/RESULTS/raw archive；无历史证据改写。

残余边界：仅合成 TEST_ONLY DB 登录/assignment，不是真实身份；行/哈希/object key 不是不可变对象内容证明；同 cluster 新 DB restore 不是跨 cluster DR 认证；队列 at-least-once，无 exactly-once、真实 Worker/API/202、真实审批、ReviewDecision、ShareGrant 或对外 outbox；Human Gold 0/26。未触及 Codex2 分支，未运行真实模型、客户数据、付费或部署。

最终原日志、GitHub 元数据、下载原 ZIP 和只读审计输出保留于 `docs/03-engineering/ra4a-p1/post-ci/469ccb6cf88b7a66d97b2572be7653048a513dd0/`，按已提交 exact-head receipt protocol 保持 uncommitted，避免变更已测 HEAD。PR 保持 Draft / unmerged / auto_merge=null。**等待 Owner 对 Critical STOP 的决策；当前不能申请 RA4A_P1_FINAL_PASS。**
