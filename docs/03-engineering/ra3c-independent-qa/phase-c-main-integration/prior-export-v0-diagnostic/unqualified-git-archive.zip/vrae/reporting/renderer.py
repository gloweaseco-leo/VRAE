"""Pure internal HTML formatter. Public export must replay ReportDraft via render()."""
import base64
import hashlib
from html import escape
import json
from urllib.parse import urlsplit

from .common import display_text, fail

RENDERER_VERSION = 'ra3c-html-1.0.1'
CSS = r'''
:root{color-scheme:light;--ink:#18313e;--muted:#59666c;--line:#dce3e1;--paper:#fff;--sand:#f3f0e9;--accent:#925332;--green:#256253;--soft:#edf5f1}
*{box-sizing:border-box}html{scroll-behavior:auto;scroll-padding-top:24px}body{margin:0;background:var(--sand);color:var(--ink);font:14px/1.65 "Segoe UI","Microsoft YaHei","PingFang SC",Arial,sans-serif}a{color:var(--green);text-decoration-thickness:1px;text-underline-offset:4px}a:focus-visible,summary:focus-visible,section:focus-visible{outline:3px solid #a96736;outline-offset:5px}button{font:inherit}code,pre,.mono{font-family:Consolas,"SFMono-Regular",monospace;overflow-wrap:anywhere;word-break:break-word}code{font-size:.92em}bdi{unicode-bidi:isolate}h1,h2,h3,p{margin:0}h1{font-size:clamp(27px,3.1vw,40px);line-height:1.35;letter-spacing:-.025em;max-width:760px}h2{font-size:20px;line-height:1.45}h3{font-size:14px}small{font-size:12px}.eyebrow{font-size:11px;letter-spacing:.15em;font-weight:700;text-transform:uppercase}.muted{color:var(--muted)}.private-bar{padding:11px 24px;background:var(--ink);color:#fff;display:flex;justify-content:center;gap:12px;flex-wrap:wrap;font-size:12px;letter-spacing:.025em}.private-bar strong{font-weight:700}.sheet{max-width:1100px;margin:28px auto;background:var(--paper);border:1px solid #d6ddd8;padding:36px 42px 25px;box-shadow:0 12px 45px #18313e09}.masthead{display:flex;align-items:center;justify-content:space-between;gap:20px;padding-bottom:23px;border-bottom:1px solid var(--line)}.brand{font-size:24px;font-weight:800;letter-spacing:.2em;line-height:1.15}.brand-sub{margin-top:6px;color:var(--muted);font-size:10px;letter-spacing:.19em}.edition{text-align:right;font-size:12px;color:var(--muted)}.edition strong{display:block;color:var(--ink);font-size:13px}.hero{padding:27px 0 24px;display:grid;grid-template-columns:1fr 175px;align-items:end;gap:28px}.hero .eyebrow{color:var(--accent);margin-bottom:10px}.intro{max-width:650px;color:var(--muted);margin-top:12px}.count{border-left:1px solid var(--line);padding-left:24px}.count strong{font-size:48px;line-height:1.1;font-weight:500;display:block}.count span{display:block;font-size:12px;margin-top:8px}.site-line{display:flex;gap:8px 22px;flex-wrap:wrap;padding:13px 0;border-top:1px solid var(--line);font-size:12px}.journey{margin:12px 0 27px;display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:1px;background:var(--line);border:1px solid var(--line)}.step{background:#fafbf9;padding:13px 12px}.step .eyebrow{font-size:9px;letter-spacing:.06em;overflow-wrap:anywhere}.step strong{display:block;font-size:14px;margin:3px 0}.step small{color:var(--muted);font-size:11px}.body-grid{display:grid;grid-template-columns:minmax(0,1fr) 270px;gap:30px}.section-title{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:15px}.section-title h2{font-size:16px}.issue{border:1px solid var(--line);border-top:3px solid var(--accent);padding:22px;margin-bottom:18px;scroll-margin-top:24px}.issue-head{display:flex;align-items:start;gap:13px;margin-bottom:16px}.number{font-size:13px;color:var(--accent);font-weight:700;border:1px solid #dbc4b4;padding:2px 7px;flex-shrink:0}.issue-head h2{font-size:20px}.tag{display:inline-block;color:var(--green);font-size:11px;font-weight:700;letter-spacing:.04em;margin-top:3px}.fact{background:var(--soft);padding:14px 16px;border-left:2px solid var(--green)}.label{font-size:11px;font-weight:700;letter-spacing:.06em;color:var(--green);margin-bottom:5px}.fact-line{font-size:15px;font-weight:600}.route{display:flex;align-items:center;gap:9px;flex-wrap:wrap;margin-top:9px;font-size:12px}.route .status{padding:1px 7px;border:1px solid #c4d4cb;background:#fff}.cite{display:inline-block;margin-top:10px;font-size:12px}.proposals{display:grid;gap:13px;margin-top:16px}.proposal{border-top:1px solid var(--line);padding-top:12px}.proposal .label{color:var(--accent)}.proposal p{font-size:13px;color:#344a54}.review-pill{display:inline-block;font-size:10px;border:1px solid #d7c2b3;color:#834c2d;padding:0 5px;margin-left:5px;letter-spacing:0;font-weight:500}.side-block{padding-bottom:20px;margin-bottom:18px;border-bottom:1px solid var(--line)}.side-block h2{font-size:14px;margin-bottom:10px}.side-block p,.side-block li{font-size:12px;color:var(--muted)}.side-block ul{padding-left:18px;margin:7px 0}.source-fact{margin-top:12px;border-left:2px solid var(--line);padding-left:11px}.source-fact .label{font-size:10px;color:var(--muted)}blockquote{margin:4px 0;color:var(--ink);font-size:12px;overflow-wrap:anywhere;white-space:pre-wrap}.source-fact a{font-size:11px}.next{padding:15px;background:#f6f3ed}.next h2{font-size:14px;margin-bottom:7px}.next p{font-size:12px;color:var(--muted)}.next button{margin-top:12px;width:100%;text-align:left;background:#e8e6df;border:1px solid #cfd0c6;border-radius:0;padding:10px 12px;color:#586461;cursor:not-allowed;font-size:12px}.empty{border:1px solid #cddbd3;border-top:3px solid var(--green);padding:24px;margin-bottom:18px}.empty h2{font-size:22px;margin-bottom:12px}.empty p{font-size:13px;color:var(--muted)}.empty .label{margin-bottom:9px}.scope-table{width:100%;border-collapse:collapse;margin-top:10px;font-size:11px}.scope-table th,.scope-table td{text-align:left;padding:7px 4px;border-bottom:1px solid var(--line);vertical-align:top;overflow-wrap:anywhere}.footer{border-top:1px solid var(--line);padding-top:18px;margin-top:22px;display:grid;grid-template-columns:1fr 220px;gap:20px;font-size:11px;color:var(--muted)}.footer strong{color:var(--ink)}.hashes{text-align:right;overflow-wrap:anywhere}.hashes code{font-size:10px}.evidence-record{display:none;max-width:1100px;margin:28px auto;background:#fff;border:2px solid var(--green);padding:30px 40px}.evidence-record:target{display:block}.evidence-record h2{margin:15px 0}.evidence-record pre{white-space:pre-wrap;background:#f2f5f2;padding:16px;font-size:12px;max-height:450px;overflow:auto}.evidence-record dl{display:grid;grid-template-columns:145px minmax(0,1fr);gap:8px 14px;font-size:12px}.evidence-record dt{color:var(--muted)}.evidence-record dd{margin:0;overflow-wrap:anywhere}.evidence-record details{margin-top:18px;border-top:1px solid var(--line);padding-top:13px}.evidence-record summary{cursor:pointer;font-weight:600}.skip-link{position:absolute;left:12px;top:-100px;padding:10px;background:#fff;z-index:10}.skip-link:focus{top:8px}
@media(max-width:740px){.sheet{margin:14px 10px;padding:23px 20px 20px}.private-bar{padding:10px 16px;gap:3px 10px;font-size:11px}.masthead{gap:12px;padding-bottom:18px}.brand{font-size:20px;letter-spacing:.16em}.brand-sub{font-size:8px}.edition{font-size:10px;max-width:120px}.edition strong{font-size:11px}.hero{grid-template-columns:1fr;gap:18px;padding:24px 0 20px}.count{display:flex;align-items:center;gap:13px;border-left:0;border-top:1px solid var(--line);padding:14px 0 0}.count strong{font-size:32px}.count span{margin:0}.intro{font-size:13px}.journey{grid-template-columns:1fr;margin-bottom:22px}.step{display:grid;grid-template-columns:112px 1fr;gap:2px 8px;padding:9px 12px}.step .eyebrow{grid-column:1;font-size:8px}.step strong{grid-column:1;grid-row:2;font-size:13px;margin:0}.step small{grid-column:2;grid-row:1/3;align-self:center;font-size:11px}.body-grid{grid-template-columns:1fr;gap:10px}.issue{padding:17px 15px}.issue-head{gap:9px}.issue-head h2{font-size:18px}.fact{padding:13px}.fact-line{font-size:14px}.proposals{gap:12px}.side-block{padding-bottom:15px;margin-bottom:15px}.footer{grid-template-columns:1fr;gap:13px;font-size:10px}.hashes{text-align:left}.evidence-record{margin:14px 10px;padding:20px 17px}.evidence-record dl{grid-template-columns:1fr;gap:2px}.evidence-record dd{margin-bottom:10px}.evidence-record pre{padding:12px;font-size:11px}.scope-table{font-size:11px}.site-line{font-size:11px}}
@media print{@page{size:A4;margin:10mm}body{background:#fff;font-size:11px}.private-bar{background:#fff;color:#18313e;border-bottom:1px solid #18313e;padding:4px;font-size:9px}.sheet{margin:0;padding:15px 0 0;border:0;box-shadow:none;max-width:none}.hero{padding:17px 0;grid-template-columns:1fr 130px;gap:15px}h1{font-size:25px}.intro{font-size:10px;margin-top:7px}.masthead{padding-bottom:13px}.brand{font-size:21px}.count strong{font-size:35px}.site-line{font-size:10px;padding:8px 0}.journey{margin:7px 0 15px}.step{padding:7px}.step strong{font-size:11px}.step small{font-size:9px}.step .eyebrow{font-size:7px}.body-grid{grid-template-columns:minmax(0,1fr) 210px;gap:18px}.issue{padding:13px;margin-bottom:10px;break-inside:avoid}.issue-head{margin-bottom:10px}.issue-head h2{font-size:16px}.fact{padding:10px}.fact-line{font-size:12px}.proposals{gap:7px;margin-top:10px}.proposal{padding-top:7px}.proposal p{font-size:10px}.label{font-size:9px}.side-block p,.side-block li{font-size:10px}.source-fact{margin-top:8px}blockquote{font-size:10px}.next button{font-size:10px;padding:7px}.footer{margin-top:12px;padding-top:10px;font-size:9px}.hashes code{font-size:8px}.evidence-record,.evidence-record:target{display:none}}
'''
CSS += r'''
@media print{.multi-issue .body-grid{grid-template-columns:1fr;gap:6px}.multi-issue .issue{display:grid;grid-template-columns:190px minmax(0,1fr);gap:6px 12px;padding:9px;margin-bottom:7px}.multi-issue .issue-head{grid-column:1/-1;margin-bottom:1px}.multi-issue .issue-head h2{font-size:13px}.multi-issue .issue-head .tag{font-size:8px}.multi-issue .fact{padding:8px}.multi-issue .fact-line{font-size:10px}.multi-issue .fact small{font-size:8px}.multi-issue .fact .route{font-size:9px;margin-top:5px}.multi-issue .cite{font-size:8px;margin-top:5px}.multi-issue .proposals{grid-template-columns:repeat(3,minmax(0,1fr));gap:9px;margin-top:0}.multi-issue .proposal{border-top:0;padding-top:0}.multi-issue .proposal p{font-size:9px;line-height:1.5}.multi-issue .proposal .label{font-size:8px}.multi-issue .review-pill{font-size:7px;margin-left:0}.multi-issue aside{display:block}.multi-issue aside .side-block:last-child{display:none}.multi-issue .scope-table,.multi-issue .scope-table tbody{display:block}.multi-issue .scope-table thead{display:none}.multi-issue .scope-table tr{display:inline}.multi-issue .scope-table td{display:inline;padding:0 4px 0 0;border:0}.multi-issue .scope-table tr:after{content:" · ";white-space:pre}.multi-issue aside .side-block p{font-size:8px;display:inline}.multi-issue aside .side-block{padding:2px 0;margin:0}.multi-issue aside .side-block h2{font-size:9px;display:inline;margin-right:8px}.multi-issue .hero{padding:10px 0}.multi-issue .hero h1{font-size:21px}.multi-issue .intro{font-size:9px}.multi-issue .section-title{margin-bottom:6px}.multi-issue .closing-grid{padding-top:7px}.multi-issue .footer{margin-top:8px}}
'''
CSS += r'''
.closing-grid{display:grid;grid-template-columns:1.3fr 1fr;gap:28px;margin-top:6px;padding-top:18px;border-top:1px solid var(--line)}.limits-inline h2{font-size:14px}.limits-inline ul{padding-left:17px;margin:8px 0 0;color:var(--muted);font-size:12px}.limits-inline li{margin-bottom:4px}.fact .cite{display:block;margin-top:9px}.scope-table td:last-child{white-space:nowrap}.coverage-mode .body-grid{grid-template-columns:1fr;gap:4px}.coverage-mode aside{display:grid;grid-template-columns:1fr 1fr;gap:28px}.coverage-mode .side-block{margin-bottom:0;border-bottom:0}.closing-grid .next{padding:15px 18px}.closing-grid .next button{margin-top:10px}.body-grid aside .side-block:last-child{border-bottom:0;margin-bottom:0}
@media(max-width:740px){.closing-grid{grid-template-columns:1fr;gap:18px;margin-top:6px;padding-top:18px}.coverage-mode aside{grid-template-columns:1fr;gap:0}.limits-inline ul{font-size:12px}.coverage-mode .side-block{border-bottom:1px solid var(--line);margin-bottom:14px}.closing-grid .next{padding:15px}}
@media print{.journey{grid-template-columns:repeat(5,minmax(0,1fr))}.step{display:block;padding:6px}.count{display:block;border-top:0;border-left:1px solid var(--line);padding:0 0 0 16px}.footer{grid-template-columns:1fr 190px}.hashes{text-align:right}.closing-grid{gap:15px;margin-top:4px;padding-top:10px;grid-template-columns:1.25fr 1fr}.limits-inline ul,.closing-grid .next p{font-size:9px;line-height:1.5}.limits-inline h2,.closing-grid .next h2{font-size:11px}.closing-grid .next{padding:10px}.closing-grid .next button{margin-top:6px;font-size:9px}.closing-grid .next .eyebrow{font-size:8px}.coverage-mode aside{gap:18px;grid-template-columns:1fr 1fr}.side-block{padding-bottom:10px;margin-bottom:10px}.side-block h2{margin-bottom:6px;font-size:12px}.scope-table{font-size:9px}.scope-table td,.scope-table th{padding:5px 3px}}
'''


CSS += r'''
@media print{.issue .proposals{grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}.issue .proposal p{font-size:9px;line-height:1.5}.issue .proposal .label{font-size:8px}.issue .review-pill{font-size:7px;margin-left:0}.issue .proposal .cite{font-size:8px}.issue .proposal{padding-top:6px}.hero{padding:12px 0}.masthead{padding-bottom:10px}.footer{gap:12px}.footer .hashes{font-size:8px}}
'''


CSS += r'''
@media print{.coverage-mode .empty{padding:15px;margin-bottom:10px}.coverage-mode .empty h2{font-size:18px;margin-bottom:7px}.coverage-mode .hero{padding:9px 0}.coverage-mode .intro{font-size:9px}.coverage-mode .section-title{margin-bottom:10px}.coverage-mode .side-block{padding-bottom:5px}}
'''


CSS += r'''
@media print{.multi-issue{font-size:9px;line-height:1.4}.multi-issue .masthead{padding-bottom:7px}.multi-issue .hero{padding:7px 0}.multi-issue .hero .eyebrow{margin-bottom:5px;font-size:9px}.multi-issue .hero h1{font-size:20px}.multi-issue .intro{margin-top:5px;font-size:9px}.multi-issue .site-line{padding:6px 0;font-size:9px}.multi-issue .journey{margin:6px 0 9px}.multi-issue .step{padding:5px}.multi-issue .step small{font-size:8px}.multi-issue .issue{grid-template-columns:290px minmax(0,1fr);gap:4px 10px;padding:8px}.multi-issue .fact-line{font-size:9px;line-height:1.4}.multi-issue .fact .label{font-size:8px}.multi-issue .fact small{font-size:7.5px}.multi-issue .fact .route{font-size:8px;margin-top:4px}.multi-issue .fact{padding:7px}.multi-issue .proposal p{font-size:8.5px;line-height:1.4}.multi-issue .proposal .cite{font-size:7px}.multi-issue .proposals{gap:7px}.multi-issue .proposal .label{font-size:7px}.multi-issue .review-pill{font-size:6.5px}.multi-issue .closing-grid{padding-top:6px}.multi-issue .limits-inline ul,.multi-issue .next p{font-size:8px}.multi-issue .footer{font-size:8px;padding-top:7px}.multi-issue .next button{font-size:8px;padding:5px}}
'''


CSS += r'''
@media print{.multi-issue .count strong{font-size:24px}.multi-issue .count span{font-size:9px;margin-top:3px}.multi-issue .hero h1{font-size:18px}.multi-issue .hero{align-items:start;padding:5px 0}.multi-issue .brand{font-size:18px}.multi-issue .brand-sub{font-size:7px;margin-top:3px}.multi-issue .edition{font-size:8px;line-height:1.4}.multi-issue .edition strong{font-size:9px}.multi-issue .masthead{padding-bottom:5px}.multi-issue .closing-grid .next{padding:7px}.multi-issue .limits-inline ul,.multi-issue .closing-grid .next p{font-size:7.5px;line-height:1.3}.multi-issue .limits-inline li{margin-bottom:2px}.multi-issue .closing-grid .next button{font-size:7.5px;margin-top:4px}.multi-issue .footer{margin-top:6px;line-height:1.3}}
'''


def asset_hash():
    return hashlib.sha256((RENDERER_VERSION + '\n' + CSS).encode('utf-8')).hexdigest()


def _t(value, bound=4096):
    return escape(display_text(str(value), bound), quote=True)


def _eid(claim):
    return 'ev-' + claim['binding_ref'][3:]


def _link(claim, label='原始证据 · 页内回查'):
    return f'<a class="cite" href="#{_eid(claim)}">{_t(label)} →</a>'


def _journey(row, issues):
    values = {o['result'] for o in row['observations']}
    if row['task'] == 'INQUIRE' and issues:
        state = '一条已绑定的路径问题' if len(issues) == 1 else '存在已绑定的路径问题'
    elif 'ACCESS_BLOCKED' in values:
        state = '部分受限 · 无法完整判断'
    elif 'PASS' in values:
        state = '仅静态片段／链路已检查'
    else:
        state = '证据不足 · 尚不能判断'
    return (f'<div class="step"><span class="eyebrow">{_t(row["task"])}</span>'
            f'<strong>{_t(row["label"])}</strong><small>{state}</small></div>')


def _issue(issue, index):
    claim = issue['fact_claim']
    status = issue['target_response']['http_status']
    href = claim['fact']['source']['citation']['raw_href']
    proposals = ''
    labels = {'impact': '对采购任务的可能影响', 'action': 'VEYFRONT 候选动作', 'recheck': '如何重新验证'}
    pending = {'impact': '假设 · 待复核', 'action': '候选 · 待批准', 'recheck': '方案 · 待批准'}
    for role, label in labels.items():
        c = issue['proposals'][role]
        proposals += (f'<div class="proposal"><div class="label">{label}'
                      f'<span class="review-pill">{pending[role]}</span></div>'
                      f'<p>{_t(c["text"])}</p>{_link(c, "复核该提议的来源绑定")}</div>')
    return (f'<article class="issue" id="issue-{index}" aria-labelledby="issue-title-{index}">'
        f'<div class="issue-head"><span class="number">{index:02d}</span><div>'
        f'<h2 id="issue-title-{index}">产品 → 联系路径返回 HTTP {status}</h2>'
        '<span class="tag">INQUIRE · 静态路径问题</span></div></div>'
        '<div class="fact"><div class="label">观察到的事实 · 仅本次采集</div>'
        '<p class="fact-line">记录中的产品页静态链接，指向的联系路径未返回成功页面。</p>'
        f'<div class="route"><code><bdi>{_t(href)}</bdi></code><span>→</span>'
        f'<span class="status">HTTP {status}</span></div>'
        f'<small class="muted">源页面：<bdi>{_t(issue["source_page"]["url"], 2048)}</bdi></small><br>'
        f'<small class="muted">采集：{_t(issue["source_page"]["observed_at"])}</small>'
        f'{_link(claim)}</div><div class="proposals">{proposals}</div></article>')


def _evidence(claim, document):
    fact = claim['fact']
    source, cite = fact['source'], fact['source']['citation']
    values = [('Claim 状态', claim['status']), ('精确原始陈述', claim['text']),
              ('规则／版本', fact['rule_id'] + ' / ' + fact['rule_version']),
              ('原始源页面', cite['url']), ('原始定位', cite['locator']),
              ('字节区间', f'{source["byte_start"]}–{source["byte_end"]} · UTF-8 原始字节'),
              ('捕获时间', cite['observed_at']), ('来源 coverage', source['coverage_status']),
              ('Observation', fact['observation_id']), ('Evidence', cite['evidence_ref']),
              ('Binding', claim['binding_ref']), ('Guard', claim['guard_ref']),
              ('EvidencePack', document['pins']['expected_pack_ref']),
              ('RuleExecution', document['pins']['expected_execution_ref']),
              ('FindingPackage', document['pins']['expected_package_ref'])]
    target = source.get('target_response')
    if target:
        values.extend([('目标 URL', target['url']), ('最终目标 URL', target['final_url']),
                       ('捕获的 HTTP', str(target['http_status']))])
    fields = ''.join(f'<dt>{_t(k)}</dt><dd><bdi>{_t(v)}</bdi></dd>' for k, v in values)
    bridge = next((i['native_bridge'] for i in document['issues'] if
                   i['finding']['observation_id'] == fact['observation_id']), None)
    proof = json.dumps({'claim': claim, 'native_bridge': bridge, 'scope': document['scope'],
                        'source_pins': document['pins']}, ensure_ascii=False, sort_keys=True, indent=2)
    return (f'<section class="evidence-record" id="{_eid(claim)}" tabindex="-1" aria-label="私有证据回查">'
            '<a href="#report">← 返回一页报告</a><p class="eyebrow">PRIVATE EVIDENCE · NOT APPROVED</p>'
            '<h2>逐条来源回查</h2><p class="muted">以下为保留的原文与引用，作为纯文本展示；不是可执行网页，也不是真实性背书。</p>'
            f'<pre aria-label="原始 HTML 引文">{_t(source["quote"])}</pre><dl>{fields}</dl>'
            f'<details><summary>查看完整 claim／target／版本绑定</summary><pre>{_t(proof, 100000)}</pre></details></section>')


def render_document(d):
    if (d['private'] is not True or d['shareable'] is not False
            or d['approval_status'] != 'NOT_APPROVED' or d['semantic_approval'] is not False):
        fail('REPORT_RENDER_STATE')
    issues = d['issues']
    title = '先让产品页的联系路径走通。' if issues else '先看已检查范围，再作判断。'
    intro = ('本次静态捕获发现了可回查的联系路径问题。建议先核实并修复这条具体路径，'
             '再讨论更广泛的采购体验改进。' if issues else
             '本次没有形成可报告的客观问题。请结合下方已检查范围与证据限制理解结果；'
             '这不等于全站健康，也不代表询盘流程已经完成验证。')
    issue_html = ''.join(_issue(issue, i) for i, issue in enumerate(issues, 1))
    if not issues:
        issue_html = ('<section class="empty"><div class="label">PRIVATE COVERAGE SUMMARY</div>'
            '<h2>0 项可报告问题</h2><p>没有以未知、受限或缺失证据补造问题；本次仅保留覆盖与原文摘要，'
            '不据此确认全站没有问题。</p></section>')
    positives = ''
    labels = {'INFO-01': '产品原文 · 不核实规格真实性', 'TRUST-01': '企业自述 · 非实体／证书核验',
              'SEO-01': '原始标题 · 非 Google 表现'}
    for claim in d['positive_source_claims']:
        cite = claim['fact']['source']['citation']
        positives += (f'<div class="source-fact"><div class="label">{labels[claim["fact"]["rule_id"]]}</div>'
            f'<blockquote>“{_t(cite.get("text", claim["fact"]["source"]["quote"]))}”</blockquote>'
            f'{_link(claim, "核对原文")}</div>')
    if not positives:
        positives = '<p>没有纳入本页的已绑定正向原文；不据此判断企业或产品质量。</p>'
    rows = ''
    for page in d['examined_pages']:
        status = str(page['http_status']) if page['http_status'] is not None else 'UNKNOWN'
        if page['status'] == 'ACCESS_BLOCKED':
            status += ' · 受限'
        elif page['status'] != 'FETCHED':
            status += ' · 无法判断' if page['http_status'] not in (404, 410) else ' · 响应已记录'
        url = urlsplit(page['url'])
        recorded_path = url.path + ('?' + url.query if url.query else '')
        rows += f'<tr><td><bdi>{_t(recorded_path, 2048)}</bdi></td><td>{_t(status)}</td></tr>'
    limits = ''.join(f'<li>{_t(t)}</li>' for t in d['limitations'][:4])
    claims = [i['fact_claim'] for i in issues] + [c for i in issues for c in i['proposals'].values()] + d['positive_source_claims']
    evidence = ''.join(_evidence(c, d) for c in claims)
    csp_hash = base64.b64encode(hashlib.sha256(CSS.encode('utf-8')).digest()).decode('ascii')
    csp = (f"default-src 'none'; style-src 'sha256-{csp_hash}'; script-src 'none'; connect-src 'none'; "
           "img-src 'none'; font-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'; frame-src 'none'")
    more = ''
    if d['omitted_eligible_issues'] or d['unsupported_rule_findings']:
        more = (f'<p class="muted">另有 {_t(d["omitted_eligible_issues"])} 个可报告路径未列入本页；'
                f'{_t(d["unsupported_rule_findings"])} 条其他规则发现尚未具备本页的逐条支持。</p>')
    html = f'''<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="{escape(csp, quote=True)}"><meta name="referrer" content="no-referrer">
<title>VEYFRONT｜私有 L1 诊断草稿｜{_t(d['site_host'])}</title><style>{CSS}</style></head>
<body><a class="skip-link" href="#main-content">跳至诊断内容</a>
<div class="private-bar" role="note"><strong>合成工业样本 · 私有预览</strong><span>NOT APPROVED · 未经人工批准 · 不可客户外发</span></div>
<main class="sheet{' coverage-mode' if not issues else ' multi-issue' if len(issues) > 1 else ''}" id="report"><header class="masthead"><div><div class="brand">VEYFRONT</div><div class="brand-sub">REBUILD ADVISORY / BUYER EXPERIENCE</div></div>
<div class="edition"><strong>{'L1 网站初步诊断' if issues else 'L1 检查范围摘要'}</strong>内部审阅稿 · v{_t(d['metadata']['version'])}<br>无真实模型调用</div></header>
<section class="hero"><div><p class="eyebrow">从海外采购商的下一步出发</p><h1>{title}</h1><p class="intro">{intro}</p></div>
<div class="count"><strong>{len(issues):02d}</strong><span>项有证据支持的本页问题<br><span class="muted">不评分 · 不补造问题</span></span></div></section>
<div class="site-line"><span>实际采集站点 <strong><bdi>{_t(d['site_host'])}</bdi></strong></span><span>记录页面 {len(d['examined_pages'])} 个</span><span>草稿时间 {_t(d['metadata']['created_at'])}</span></div>
<nav class="journey" aria-label="海外采购任务与本次静态检查范围">{''.join(_journey(r, issues) for r in d['buyer_journey'])}</nav>
<div class="body-grid" id="main-content"><section aria-label="诊断问题与人工复核提议"><div class="section-title"><h2>{'本次值得先讨论的具体问题' if issues else '本次检查结果'}</h2><span class="eyebrow">EVIDENCE FIRST</span></div>{issue_html}{more}</section>
<aside aria-label="采集范围与来源限制"><section class="side-block"><h2>已检查范围</h2><p>页首域名下的静态记录路径；路径角色不等于语义身份。</p><table class="scope-table"><thead><tr><th scope="col">记录的路径</th><th scope="col">捕获状态</th></tr></thead><tbody>{rows}</tbody></table></section>
<section class="side-block"><h2>已绑定的正向原文</h2><p>这些是来源片段，不作为缺陷，也不作为真实性或效果背书。</p>{positives}</section></aside></div>
<div class="closing-grid"><section class="limits-inline"><h2>未检查／无法判断</h2><ul>{limits}</ul></section>
<section class="next"><p class="eyebrow">下一步 · 仅内部提议</p><h2>先核实范围，再明确改造动作。</h2><p>内容与链接调整可作为 Rebuild 的候选讨论范围。平台、数据库、迁移及业务资料需单独评审；不构成报价或交付承诺。</p><button type="button" disabled aria-disabled="true">建议与 VEYFRONT 讨论下一步（未启用）</button></section></div>
<footer class="footer"><div><strong>PRIVATE / NOT_APPROVED / NO CUSTOMER SHARE</strong><br>所有假设、动作及复核方法均待人工审阅；本页不产生咨询收据或合格商机。<br>© VEYFRONT · 合成离线审阅样本 · 未检查部分不代表无问题。Human Gold 0/26，未评估准确率。</div>
<div class="hashes">编辑内容清单 SHA-256<br><code>{_t(d['editorial_content_sha256'])}</code><br>页面完整字节哈希见配套 draft.json；两者均不是批准凭据。</div></footer></main>{evidence}</body></html>'''
    return html.encode('utf-8')
