"""Synthetic-only collection tests."""
