"""Archive only final read-only receipts, without mutating the tested HEAD."""
import hashlib
import json
from pathlib import Path
import zipfile

here = Path(__file__).resolve().parent
head = '469ccb6cf88b7a66d97b2572be7653048a513dd0'
main = '225ded57add21680171cfaecac9f89df6b1af155'
pr = json.loads((here / 'final-pr-readback.json').read_text(encoding='utf-8'))
ref = json.loads((here / 'final-main-readback.json').read_text(encoding='utf-8'))
assert pr['head']['sha'] == head and pr['base']['sha'] == ref['object']['sha'] == main
assert pr['draft'] and not pr['merged'] and pr['auto_merge'] is None
assert (here / 'FINAL_CI_RECEIPT.json').exists()
assert (here / 'RA3C_V2_AND_HTTP_ACTUAL_PROOF.json').exists()
assert json.loads((here / 'CRITICAL_STOP_RECEIPT.json').read_text())['status'] == 'P1_BLOCKED_CRITICAL_STOP_PG_CANNOT_RUN'
members = []
out = here / 'final-readonly-receipts.zip'
files = sorted(p for p in here.rglob('*') if p.is_file() and '__pycache__' not in p.parts
               and p.name not in ('final-readonly-receipts.zip', 'FINAL_READONLY_MANIFEST.json'))
with zipfile.ZipFile(out, 'x', zipfile.ZIP_DEFLATED) as z:
    for p in files:
        name = p.relative_to(here).as_posix()
        raw = p.read_bytes()
        z.writestr(name, raw)
        members.append({'member': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    assert all(hashlib.sha256(z.read(r['member'])).hexdigest() == r['sha256'] for r in members)
result = {'head': head, 'main': main, 'status': 'P1_BLOCKED', 'committed': False,
          'raw_zip_sha256': hashlib.sha256(out.read_bytes()).hexdigest(), 'bytes': out.stat().st_size,
          'members': members, 'remote_receipt': 'https://github.com/gloweaseco-leo/VRAE/pull/63#issuecomment-6827081501'}
(here / 'FINAL_READONLY_MANIFEST.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: v for k, v in result.items() if k != 'members'}))
